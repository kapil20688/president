<?php
	
	include "wp-load.php";

	cron_function_email();

?>